import file 
print(file.name)
file.show(10, 20)
