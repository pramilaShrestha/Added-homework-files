# 1. What is File Handling?
# -------------------------
# File Handling is the process of creating, reading, writing, updating, and deleting files using a program.

# It allows us to store data permanently.

# Example:
# - Student Records
# - Employee Details
# - Marks
# - Notes
# - Login Information

# =========================================

# 2. Why Do We Need File Handling?
# --------------------------------

# Without File Handling
# ---------------------
# name = "Ram"

# Program Closed
# ↓
# Data Lost

# With File Handling
# ------------------
# Program writes data into a file.

# Program Closed
# ↓
# Data is still available.

# =========================================

# 3. What is a File?
# ------------------

# A file is a collection of data stored permanently on a storage device.

# Examples:
# students.txt
# marks.txt
# notes.txt

# =========================================

# 4. Types of Files
# -----------------

# 1. Text File
# ------------
# Stores readable text.

# Examples:
# student.txt
# notes.txt
# data.csv

# 2. Binary File
# --------------
# Stores binary data.

# Examples:
# image.jpg
# video.mp4
# music.mp3
# document.pdf

# =========================================

# 5. Steps of File Handling
# -------------------------

# Step 1: Open the File # kun file ho k kam garni
# Step 2: Perform Operations # kina open gareko 
#         (Read / Write / Append)
# Step 3: Close the File

# this process is call file handling



# data base ma kunai file collect garni ho 

# lage data haru xa vani database use garxau 
# but python le gareko sa-sana rpject chai file handling nai garxau

# yadi aauta data base ma vayako data arko database ma switch garnu
# paryo vani file hanling nai use garxau
# sano sano file implort garnu paryo vani pani FH Use garxau

# 6. open() Function
# Syntax
# file = open("filename", "mode")

# open = function of opening file
# mode = purpose of opening file

# x ----> create
# f = open("msg.txt", "x")

# r ------> read
# f = open("msg.txt", 'r')
# c
# print(f.readline())
# print(f.readlines())


# w ----write
# f = open("msg.txt", 'w')
# f.write("hello world") # asle chai naya data lei nai overirde garera purano lai matra rakheko xa
# f.write("welcome")

# a-----> append
# f = open("msg.txt", 'a')
# f.write("hello world")
# f.write("welcome")
# r+ 
# w+ 
# a+

# f = open("msg.txt", 'r+') # read write dubau garna pauxa
# f.write("welcome") # r mode vayako le write garna paudaina ya
# # r + ralhesi read ride garna payo
# print(f.read())



# f = open("msg.txt", 'r')
# print(f.read(10))

# closed
# print(f.closed) # false vaneko file closed xaina


# file closed garnako laghi 
# f.close()

# what happent when we donot close file ? 
# data will be corrupt
# Data may not be saved properly.
# Memory and system resources remain occupied.
# It can cause resource leaks.

"""""
try:
    f = open("msg.txt", 'w')
    print(f.read(10))

# closed
finally:
    print(f.closed) """

# ya chai hamro file opent vyasi error aayo 
# jasle memory chai wast hunxa 

# Tesaile 
# with open("msg.txt", 'r') as f:
#     print(f.read(20))

# with statement le 4 ota space bahira code lekhsi automatice close garinxa


# tell()
# seek()
# f = open("msg.txt", 'r')
# print(f.read(10))
# print(f.tell())
# print(f.read(5))
# print(f.tell())


# aba bata malai suru bata chaiyako xa vani
# f = open("msg.txt", 'r')
# a = f.read(10)
# print(a)

# f.seek(0)
# print(f.read(10))

# f.close()

# --------------------
# delete file
import os
os.remove("msg.txt")