def multiply(*v):
    """Multiplies all the arguments together."""
    result = 1
    for i in v:
        result *= i
    return result

