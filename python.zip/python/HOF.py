# a = ["pramila", "hari", "tam"]

# for i in a :
#     print(i)


# high order function : aauta fun jun le lai chai function lai
# ko rupma   as a argument ko rupama lina


a = ["pramila", "hari", "tam"]

print(min(a, key = len))


# three Buit-in higher order functions
# 1. map()
# 2. filter()
# 3. reduce()

# map

# def show(a):

#     return a + 2

# v = [1,2,3,4,5]

# print(show(v))

# 1. map(): 
# map() Python ko ek built-in Higher Order Function ho jasle iterable 
# (list, tuple, set, etc.) ko pratyek element ma euta function apply 
# garera naya iterator object return garcha.

def show(a):

    return a + 2

v = [1,2,3,4,5]

result =map (show, v)  

print(list(result))


# short way 

v = [1,2,3,4,5]
result = map(lambda x: x ** 2, v)
print(list(result))




# filter() le iterable bata condition milne element matra select garcha

numbers = (1,2,3,4,5,6,7,8,10,11,12,13,44)

def show(c):
    return c % 2 == 0 

var = filter(show, numbers)

print(list(var))


# # reduce : “reduce() le list ko sabai values lai jodera, multiply garera, 
# ya combine garera euta matra output banaucha.”

from functools import reduce

num = [ 1,2,3,4,5,6,7,8]

def mul (x, y):
    return  x * y 

result = reduce(mul, num)

print(result)








