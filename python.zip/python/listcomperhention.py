
# list Comperhention: short and efficienct way to creat new list using for loop 
# and condition. 

## Syntax

# [expression for item in iterable]


# numbers = [1, 2, 3, 4, 5]

# new_list = []

# for num in numbers:
#     new_list.append(num * 2)

# print(new_list)


# using list comperhention 

# numbers = [1, 2, 3, 4, 5]
# result = [num * 2 for num in numbers]
# print(result)


# result = [x  for x in range(1,11)]
# print(result)


# With Condition

# [expression for item in iterable if condition]

# list1 = [1,2,3,4,5,6,7,8,9,10]
# result = [x for x in list1 if x % 2 == 0]
# print(result)


# list1 = [1,2,3,4,5,6,7,8,9,10]
# result = ["Even"  if i % 2==0 else "odd" for i in list1]
# print(result)




# # list comperhention 
# # syntax: 
# # new_list = [expression for item in iterable]


# # number = []
# # for i in range(5):
# #     number.append(i)

# # print(number)  



# # numbers = [i for i in range(5) ]
# # print(numbers)


# # square = [i*i for i in range(1,6) ]
# # print(square)




# # list comprehension with if condition
# # Syntax: 
# # new_list = [expression for item in iterable if condition]


# # even = [i for i in range(1,11) if i%2 == 0]

# numbers = [2,4,7,9,1,10]

# result = [x for x in numbers if x > 5 ]
# print(result)



# fruits = ["Apple", "Banana", "Orange", "Avocaodo"]
# result = [fruit for fruit in fruits if fruit.startswith("A")]
# print(result)




# # # list comprehension with if  else

# # [expression_if_true if condtion else expression_if_false for item in iterable]
# result = ["Even" if i%2 == 0 else "odd" for i in range(1,6)]
# print(result)



