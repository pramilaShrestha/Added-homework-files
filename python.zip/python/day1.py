# # #  Python is a dynamically typed, General Purpose Programming
# # a = "hj"

# # # Language that supports an object-oriented programming approach
# # # as well as a functional programming approach.

# # # ● Python is also an interpreted and high-level programming
# # # language.
# #  # 


# # # ● It was created by Guido Van Rossum in 1989.


# # # Case 

# # # total_amount  =  67
# # # print(total_amount)


# # # Variable : 

# # # datatyes: 
# # # Numeric data types : integers, float, complex
# # # Sequence data types: list, tuple, range
# # # text  : String
# # # set
# # # Mapped 
# # # Bytearray 

# # # Numeric data types : integers, float, complex
# # # integers: whole number (0,1,2,3,4), 
# # # float = 567.678
# # # complex Number :  2 + i

# # a = 23
# # b = 456.6678
# # # c = 3 + i
# # Sequence data types: list, tuple, range
# # list : 
# list1 = ["helo", 1,3,5]
# tuple2 = ("helo", 1,3,5)
# range1 = (1, 5)
# list2=["hello",1,2,3]
# tuple2=("hello",1,2,4)
# print(list1)
# print(tuple2)

# # # string 
# # s1 = "hello145"
# # s2 = "ghjk678"
# # s3 = """67890ghjk"""
# # s2 = '''hjk890'''
# name="prikshya"
# age=34
# add="shankhamul"
# print(" my name is", name,"my age is",age,"i live in",add)




# dict1 = {
#     "Name": "Ram",
#     "age": 23,
#     "address": "bhaktapur"
# }

# print(dict1)


# dict2= {
#     "name": "prikshya",
#     "age": 19,
#     "address": " shankhamul"
# }

# print(dict2)





# set = {2,2,4,6,7,8,"hjk", "hi25"}

# set2 ={ 1,2,3,4,"abc", "bcaf"}
# print(set2)




a = 2455
print(type(a))
print(a)



b = 2323.6364
print(type(b))

p =[3,"dfg", 56,7,89,"shhg",647]
print(type(p))
print(p)

abc = ("hello",36474)
print(type(abc))
print(abc)



cmplx1 = 2 + 4j
cmplx2 =-(3 + 7j)
cmplx3 =-4.1j
 
print(type(cmplx1))
print(cmplx1)



