# exception handling

# 1. Syntax KeyError


# 2. Logical KeyError
# 3. Run Time error



#1.syntax error: when we write code in wrong format 
# or wrong way. It is detected by compiler or 
# interpreter and it will not execute the program.
print("hello")


# 2. Logical KeyError

#2.logical error: when we write code in correct 
# format but it gives wrong output. It is not 
# detected by compiler or interpreter and it will 
# execute the program.

a = 10
b = 20

print(a*b)


# 3. Run Time error
# runtime error: when we write code in correct format 
# but it gives error during execution. It is detected 
# by compiler or interpreter and it will not execute 
# the program.



# zero division error: 
# when we divide a number by zero. It is detected by 
# compiler or interpreter and it will not execute the 
# program.

#name Error

# print(x)

# typeError
# x = 10
# y = "20"
# print(x+y) 

# len(2345)


#index error
# lst = [1,2,3]
# print(lst[5])



#valueErron

# # Key error
# d = {'name':'john','age':30}
# print(d['gender'])


# exception Handling


# Syntax:

# try:
#     risky code
# except:
#     error handling code



# try:
#     print(10/0)
# except:
#     print("cannot divide by zero")


# 4. Flow of Exception Handling


# try:
#     code
# except:
#     handle error
# else:
#     no error bhaye
# finally:
#     always execute


# print(10/0)
try:
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))

    result = num1 / num2

except ZeroDivisionError:
    print("not divide by zero")

else:
    print(result)

finally:
    print("thank you")



