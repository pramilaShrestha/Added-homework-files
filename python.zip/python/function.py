# # function : reusable block of code. 
# # use: 
# # code reuseable
# # increase modularity
# # increase readbility


# # syntax: 

# # def function_name():
# #     block of code

# # function_name()


# # def Student(name):
# #     print("this is Sipalaya", name)

# # Student("ram")
# # Student()
# # Student()



# # def add(a, b):
# #     return a+b

# # print(add(4,5))

# # x = add(3,4)
# # print(x)

# # types of parameter and argument in funtion
# # positional Argument
# # keyword argument
# # Default argument
# # agrs
# # kwargs

# # positional Argument
# def greet(male,female):

#     print(f'welcome,{male}.He is fabuolous')
#     print(f'welcome,{female}.she is fabuolous')

# greet('sujan','siya')
# greet('siya','sujan')


# #keyword argument: position doesnot matters

# # def greet(male,female):
# #     print(f'welcome,{male}.He is fabuolous')
# #     print(f'welcome,{female}.she is fabuolous')

# # greet('sujan','siya')
# # greet(female='siya',male2='sujan')


# # default parameter 

# def greet(name="Guest"):

#     print("Hello", name)

# greet("Ram")
# greet()


# def greet(sir,name='sujan'):
#     print(f'welcome,{name}')
#     print(f'hello,{sir}')
# greet('saugat')



# # args: handles multiple positional arguments 
# # by *
# # store in form of Tuple

# def show(b,d,*a,c=1):
#    print(b)
#    print(c)
#    print(d) 
#    print(a)

# show(1,2,3,4,5)


# def show(c,b,*a):
#     print(a)
#     print(b)
#     print(c)
# show(1,2,3,4)


# #kwargs: handles multiple keyword arguments
# # by   **
# # store in form of dictionary


# def show(**info):
#     print(info)

# show(name='saurab',age=26)
# show(2,3,5,6)


# Global variable 

# A global Variable is a variable that is declared outside  a function. 
# It can  be accessed all over function. 


# a = 100  # global variable

# def student():
    
#     print(a)

# student()

# def display():
#     print(a)

# display()


# local  variable 

# A local Variable is a variable that is declared inside a function. 
# It can  be accessed only within that function. 

# def greet():
#     name = "Ram"      # Local Variable
#     print(name)

# greet()




# `name` is created inside the `greet()` function.
# It exists only while the function is executing.
# It cannot be accessed outside the function.



# a = 200  # global variable

# def student():

#     a = 100
#     b = 300
    
#     print(a+b)

# student()


# Nested functions 

# def a():
#     name= "pramila"
#     print(name)

#     def b():
#         print(name)
#         print("Sipalaya")
    
#     b()

# a()


# def A():
#     x = 10
#     print(x)

#     def B():
#         nonlocal x
#         x += 5
#         print(x)   

#     B()


# A()

# lambda function : anynomous function for calculation in single line


# syntax: s

# lambda varaible : expresion

x = lambda a,b : a+b
print(x(3,5))


























