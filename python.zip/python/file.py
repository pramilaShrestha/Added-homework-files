name = "Pramila"
def show(a, b):
    print(a + b)



