# # loop : 

# print("hello")
# print("hello")
# print("hello")
# print("hello")


# # Syntax
# Basic Syntax of for Loop in Python
# for variable in sequence:
#     statement

# Using range()
# for variable in range(number):
#     statement


# list1 = ["Pramila", "Shrestha", 1,3]
# for i in list1:
#     print(i)


# for i in range(5):
#     print("Hello")


# for i in range(1, 10, 2):
#     print(i)


# for i in range(1, 100):
#     if i % 2 == 0:
#         print(i)



# # 5 : 5 + 4 +3 +2+1
# # pattern  1 to 5
# for i in range(1, 6):
#     print(i)



# # Pattern: Numbers in Triangle Form
# n = 5

# for i in range(1, n+1):
#     for j in range(1, i+1):
#         print(j, end=" ")
#     print()

i = 1 
while i <= 20:
    if i%2 == 0 :
        print(i, end=" ")
    i += 1



