# module 
# kunai pani code dif dif thau ma barambar chahinxa vani 
# code lai module ma rakhna sakinchha


# name = [1,2,3,4,5,6,7,8]
# def show():
#     print("hello")


# module is a file tha contain code (variable, del , class, for, runnable code) that can be use in oter pyhton
# program
# Main purpose of module: 
# Main purposes:

"""1. Code Reusability
You can write code once and use it in many programs.
Example: math functions, file handling, etc.

2. Better Organization
Instead of writing everything in one file, you split code into modules.
This makes programs clean and easy to manage.

3. Saves Time
You don’t need to rewrite common functions again and again.

4. Built-in Functionality
Python already provides modules like:

math (math operations)
random (random numbers)
os (system operations)

5. Easy Maintenance
If something is wrong, you only fix that module instead of full program.

# Types : 

# module , script, package, liabrary"""

# 2.  user defined module : 
# kunai code lai barambar chahinxa vani tyo code lai 
# module ma rakhna sakinchha ani tyo module lai import 
# garera use garna sakinchha


# Scirpt File : jati pani .py wala file haru hun
# teslai hami script file vanxau 
# File.py 


# module ma chai print rakhdainam  yo chai 
# name = "Pramila"
# def show(a, b):
#     print(a + b)


# # mosule call garni tarika arko file ma 
# import file 
# print(file.name)
# file.show(10, 20)

# # Another Way
# from file import name, show
# print(name)
# show(10, 20)


# from file import *  # sabbai linu xa vani balla 1/2 ota chaiyako xa vani nalini 


# 1. Built in module: Python has many built-in modules that you can use without
# installing anything.
# Example: math, random, os, sys, datetime, etc.
# import random
# a = random.choices([1, 2, 3, 4, 5], k = 2)
# print(a)

# import keyword
# print(keyword.kwlist)

# import calendar
# print(calendar.month(2025,4))
# print(calendar.calendar(2025))

# import datetime
# print(datetime.datetime.now())
# print(datetime.datetime.now().year)
# print(datetime.datetime.now().date())
# print(datetime.datetime.now().time())


from importlib.resources import Package
import math
# v = math.sqrt(16)
# print(v)

# f = math.factorial(5)
# print(f)


s = math.sin(30)
print(s)
print (math.floor(s))
print(math.ceil(s))


print(round(3.567, 2))

from math import sqrt, radians, sin  # ak ak gari rakhnu parxa muni code ma 
# rakhnu pardaina
from math import * # yo garda sabbai aauaxa 
print(sqrt(16))



# Module Alising : 
# improve readability :  
from math import sqrt as a
print(a(16))


print(dir(math)) # math module ma k k xa vanne herna ko lagi 




# External Module: 
# These are modules that are not built into Python but can be installed and imported from third party sources.


# package : module haru ko collection lai package vanxau
# Package 
# # foder ---->
#         ---> __init__.py
#         ---> file1.py
#         ---> file2.py

# Package is a way to organize related modules together. 
# It’s like a folder that contains multiple Python files (modules) and 
# an __init__.py file to indicate that it’s a package. You can import modules from a package just like you would with regular modules.


# pip : prefer insraller program # package tanera manage garni kam pip le garxa


