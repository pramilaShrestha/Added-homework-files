# Inheritance : 

# class ParentClass:
#     # Parent class attributes and methods
#     pass

# class ChildClass(ParentClass):
    # # Child class attributes and methods
    # pass

# code reusability
# Easy Maintenance
# Reduce duplicate code 
# Extensibility

# parent class - base class
# child class Derived class


# types of Inheritance
# 1. Single Inheritance
# 2. Multiple Inheritance
# 3. Multilevel Inheritance
# 4. Hierarchical Inheritance


# 1. Single Inheritance : 
# 1 parent  and 1 child 

# class Animal:
#     def sound(self):
#         print("Aminal makes Sound")

# class Dog(Animal):
#     def bark(self):
#         print("Dog Barks")

# b1 = Dog()
# b1.sound()
# b1.bark()


# 4. Multiple Inheritance
# 2 parent class → 1 child class


# class Father:
#     def skill1(self):
#         print("Teachig")

# class Mother:
#     def skill2(self):
#         print("Cooking")

# class Child(Father, Mother):
#     def skill3(self):
#         print("Playing")


# ob1 = Child()
# ob1.skill1()
# ob1.skill2()
# ob1.skill3()


"""Create a Python program using Multiple Inheritance.
Requirements:
Create a class Calculator with a method add(a, b).
Create another class Multiplier with a method multiply(a, b).
Create a class MathOperations that inherits from both classes.
Create an object and display the sum and multiplication of 10 and 5."""



# 5. Multilevel Inheritance

# Grandparent → Parent → Child

class GrandParent:
    def show1(self):
        print("this is grandparent")

class Parent(GrandParent):
    def show2(self):
        print("this is a Parent class")

class child(Parent):
    def show3(self):
        print("this is child class")

ob1 = Parent()
ob1.show1()
ob1.show2()

ob2 = child()
ob2.show1()
ob2.show2()
ob2.show3()


# 6. Hierarchical Inheritance
# 1 parent → multiple child

class Vehicle:
    def info(self):
        print("This a Vehicle")

class Car(Vehicle):
    def car_info(self):
        print("this is Car")

class bike(Vehicle):
    def bike_info(self):
        print("this is Bike")

c1 = Car()
c1.info()
c1.car_info()

b1 = bike()
b1.info()
b1.bike_info()










