# Encpatulation : the rapping the data and method with single unit
# hiding internal state object and restrict direct access from outside

# why
# data secure
# data hiding
# contorl access to the data


# encaptulatio is achived by using access modifier and property decorator
# accress modifiefr: restrict variable and mthod access globally by making 
# private and protected

# public accessor: attribute and metho are accessible from outside class
# private : attribute and metho are accessible onlu in that class
# Potected : attribute and metho are accessible only with that 
# class and subclass
#-------------------------------------------------#
# without any accessifier
# class Student:
#     def __init__(self):
#         self.name = "Pramila"

#     def show(self):
#         print(f"hello is {self.name}")

# ob = Student()
# print(ob.name)  #variable lai class bahira bata access garna milxa
# ob.show()


# class B():
#     def display(self):
#         print("this display features", ob.name)  # mathiko variable lai ni access garna milyo

# v = B()
# v.display()

# private ali derai use garxau aru vanda
#----------------------------------------------#

# using  private accessfier in variable

# from os import name

# class Student:
#     def __init__(self):
#         self.__name = "Pramila" # private variable

#     def show(self):
#         print(f"hello is {self.__name}")

# ob = Student()
# print(ob.__name)  # private variable lai class bahira bata access garna mildaina
# ob.show() # but class vitarakai function le chai milxa access garna

# # Assari aru class mani milena acccess garna
# class B():
#     def display(self):
#         print("this display features", ob.__name)

# v = B()
# v.display()

# Technically herni ho vani hamile private lai ni bahira bata chai access garna milxa
# fully hamile secure banayara rakhna possible hudaina
# print(ob.__dict__) # asle chai Pramila vanni k name le base ko vanera dekhauxa
# print(ob._Student__name) # tyai name halera access garna milxa

# ----------------------------------------------------
# # using  private accessfier in method 

# class Student:
#     def __init__(self):
#         self.__name = "Pramila" # private variable

#     def __show(self):
#         print(f"hello is {self.__name}")

#     def display(self): # class vitrakai method le chai access garna payo 
#         self.__show()   # class vitrai arko function banayara access garna milxa

# ob = Student()
# # print(ob.__name)  # private variable lai class bahira bata access garna mildaina
# # ob.__show()  # yo chai aba direct access garna mildaina kina hamile private method accessifier use gareko xau
# ob.display()

# ----------------------------------------------------
# using  protected accessfier in variable class and subclass
# single underscore 
# protected chai derai use gardainnau kam nau use garxau 

# class Student:
#     def __init__(self):
#         self._name = "Pramila"

#     def show(self):
#         print(f"hello is {self._name}")

# ob = Student()
# print(ob._name) 
# ob.show()


# class B(Student): # Student lai call garina vani error aauxa
#     def display(self):
#         print("this is sub class", ob._name)  # mathiko variable lai ni access garna milyo

# v = B()
# v.display()

# =============================================================

# arko property decorator use garera pani kehi had samma encaptulation garna milxa
# property decorator : it aslo control access of data
# it  access method like  attribute

class Student():
    def __init__(self, name):

        self.__name = name

    @property # yo gare paxi ob.show garda kheki error aauxa
    def show(self):
        print(f"hello{self.__name}")


    @show.setter
    def show(self, value): # uta bata j value aauxa tyo chai value ma aayara basxa
        self.__name= value  # 


    @show.deleter  # show ma j vlaue auxa teslai delete garni
    def show(self):
        del self.__name

ob = Student("Hari")
# ob.show() # bahira bata direch show vanni access nadinako laghi property decorator use garxau
# aba error naaunako laghi ka garnita 
ob.show # asari parenthesis narakhi arttibute jasari call garna milxa

# aba malai feri vlaue chage garnu paryo vani hari ko thauma ram rakhnu paryo vani 
# setter method use garxau asle naya vlaue set garxa

# ob.show = "ram" # setter method le garda ya vlue chage vayara ram hunxa
# ob.show


# getter 

# del ob.show # deleter method le garda show vanni attribute delete hunxa
# ob.show



