# # Day 18 – Python OOP (Object Oriented Programming)

# ## 1. Programming Paradigms in Python

# ### Procedural Programming : c style

# * Program लाई functions र statements मा organize गरिन्छ।
# * Example: loops, functions, modules आदि।

# ### Object Oriented Programming (OOP)

# * Code लाई objects मा organize गरिन्छ।
# * Real-world entities लाई represent गर्न प्रयोग गरिन्छ।
# * Python ले Class र Object प्रयोग गरेर OOP implement गर्छ।

# ---

# ## 2. Class and Object

# ### Class

# * Object बनाउने blueprint/template हो।
# * Attributes र Methods को समूह हो।
# * group of objects को common properties र behaviors define गर्छ।

# ### Object

# * Class को instance हो।
# * Class बाट create गरिन्छ।

# ### Syntax
# class chai attribute and method milera baneko hunxa
# class StudentDetails:
#     # CODE 

# ob = StudentDetails()

# example:
class student: 
    def __init__(self, name, age):
        self.name = name # attribute/variable
        self.age = age

    def show(self):
        print(f"My name is {self.name} and age is {self.age}")

ob = student("Sujan", 99)
ob.show()


# ## 3. Attributes and Methods

# ### Attribute

# * Variable जसले object को data store गर्छ।

# ### Method

# * Function जस्तै हुन्छ।
# * Specific task perform गर्छ।

# ---

# ## 4. Constructor (**init**)

# init vaneko constructor method ho.
# object banaunda automatic run huncha ra value set garcha.

# ### Purpose

# * Object create हुँदा automatically call हुन्छ।
# * Initial value assign गर्न प्रयोग गरिन्छ।

# ## 5. self Keyword
# self vaneko current object (class bata baneko object) ho.
# yesle object ko data access garna help गर्छ.
# ```python
# self.name = name
# ```

# ### Meaning

# * Current object को reference हो।
# * Object को attributes access गर्न प्रयोग हुन्छ।

# ---

# ## 6. Student Class Example

# ```python
# class Student:

#     def __init__(self, name, age):
#         self.name = name
#         self.age = age
# self is a reference (pointer) to the current instast of class(object)
#     def show(self):
#         print(f"My name is {self.name} and age is {self.age}")

# ob = Student("Sujan", 99)
# ob.show()

# b = Student("Ram", 88)
# b.show()
# ```

# ### Output

# ```text
# My name is Sujan and age is 99
# My name is Ram and age is 88
# ```

# ---

# ## 7. Shopping System Example

# ### Requirements

# Attributes:

# * product_name
# * price
# * qty

# Methods:

# * total_price()
# * display()

# ```python
class MyShop:

    def __init__(self, product_name, price, qty):
        assert price > 0, f"Your price {price} cannot be negative value"

        self.product_name = product_name
        self.price = price
        self.qty = qty

    # def total_price(self):
        # if self.price > 0:

        print(f"Your product is {self.product_name} and total price is Rs.{self.price * self.qty}")
    #     else:
    #         print("your pric cannot be nagative")

    def display(self):
        print("Hello Sipalaya")


p = MyShop("Pen", -16, 12)

print(p.product_name)

p.total_price()
p.display()
# ```

# ---

# ## 8. Validation Using assert

# ```python
# assert price > 0, f"Your price {price} cannot be negative value"
# ```

# ### Purpose

# * Invalid data रोक्न।
# * Negative price accept नगर्न।

# ---

# ## 9. Circle Class Task

# Question:

# Create a Python program to represent a Circle.

# Attribute:

# * radius

# Methods:

# * area()
# * perimeter()

# ```python
# class Circle:

#     def __init__(self, r):
#         self.r = r

#     def area(self):
#         print("Area =", 3.14 * self.r * self.r)

#     def perimeter(self):
#         print("Perimeter =", 2 * 3.14 * self.r)


# c = Circle(4)

# c.area()
# c.perimeter()
# ```

# ---

# ## Viva Questions

# 1. What is OOP?
# 2. What is a Class?
# 3. What is an Object?
# 4. What is the purpose of **init**()?
# 5. What is self in Python?
# 6. Difference between Attribute and Method?
# 7. What is Constructor?
# 8. Why do we use assert?
# 9. How is an object created?
# 10. What are the advantages of OOP?
