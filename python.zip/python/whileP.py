# Basic
# Print numbers from 1 to 10.

# i = 1 
# while i <= 10:
#     print(i)
#     i += 1



# # Print numbers from 10 to 1.
# i = 10 
# while i >= 1 :
#     print(i)
#     i-= 1

# # Print even numbers from 1 to 20.
# i = 1 
# while i <= 20 :
#     if i % 2 == 0 :
#         print(i)
#     i += 1

# Print odd numbers from 1 to 20.
# i = 1 
# while i <= 20 :
#     if i % 2 != 0:
#         print(i)
#     i += 1

# Print your name 5 times.

# i = 1
# while i <= 5:
#     print("pramila")
#     i += 1


# Intermediate
# # Find the sum of numbers from 1 to 100.
# i = 1 
# sum = 0
# while i <= 100:
#     sum  += i
#     i += 1
# print(sum)


# Print the multiplication table of a number.

# num = int(input("Entera Num : "))

# i = 1
# while i <= 10:
#     print(num, "x", i , "=", num*i)
#     i+=1



# Count the digits of a number.
# digit = 234890000
# count = 0
# while digit != 0 :
#     digit = digit // 10
#     count += 1
# print(count)


num = abs(int(input("Enter a Number : ")))

count = 0 
while num != 0:
    num = num // 10
    count += 1
print(count)



# Reverse a number.
num = 45678
rev = 0 

while num != 0:
    digit = num % 10
    rev = rev * 10 + digit
    num = num // 10

print(rev)



# Find the factorial of a number.
# Advanced
# Check whether a number is palindrome.
# Check whether a number is Armstrong.
# Generate Fibonacci series.
# Print star patterns.
# Find prime numbers between 1 and 100.