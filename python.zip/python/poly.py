# # polymorphism
# polymorphism: one method, many forms
# polymorphism allows us to define methods in the child class 
# with the same name as defined in

# occurance of somethings in multiple forms

# a = "pramila"
# b = "ram"

# print(len(a))
# print(len(b))

# asle diff diff behavior dekhairaxa

# Compile time polymorphosm
# run time polymorphism


# class A:
#     def show(self):
#         print("I want to learn python")

# class B:
#     def show(self):
#         print("i want to learn pyton")
# ob  = A()
# ob1 = B()
# ob.show()
# ob1.show()

# def display(var):
#     var.show()

# display(ob)
# display(ob1)



# method overlodaing : compile time
# class contain more then one method with 
# same name but different parameter

# class A():
#     def show(self):
#         print("hello")

#     def show(self, a, b): # second definition ovrride first
#         print(a+b)

#     def show(self, a, b, c): # third definition ovrride second
#         print(a+b)
# ob = A()
# ob.show(2,3)
# ob.show(2,4,6)

# phile ko method lai over ride garera arko second lai use garxa
# tara python le overriding gardaina

# class A():
#     def show(self, a= None, b = None, c= None):
#         if a != None and b != None and c!=None:
#             s = a+b+c

#         elif a != None and b != None and c==None:
#              s = a+b

#         elif a == None and b == None and c==None:
#             s = "hello sipalaya"

#         print(s)

# ob = A()
# ob.show(1,2)
# ob.show(1,2,3)


# method overriding: parent ra child class name same
# whenever we writing method name with same signature in parent and child 

# class A():
#     def show(self):
#         print("ths is parent class")

# class B(A):
#     def show(self):
#         print("this is child class")


# ob = B()
# ob.show() 
# child class call hunxa ya # parent class lai override
#  garera child clas lai priority dinxa

# kahile kahi parent class ko ni properties china sakxa tetibela
# k garnita 
# tesko laghi super vannni method hunxa

# class A():
#     def show(self):
#         print("ths is parent class")

# class B(A):
#     def show(self):
#         super().show()  # super method whichis used to access 
#         # method of parent class
#         print("this is child class")

# ob = B()
# ob.show() 



# operator overloading
# when the same operator is allowed to have diff parameter
# ==============================
# Operator Overloading in Python
# ==============================

# Operator Overloading means:
# The same operator (+, -, *, etc.) can perform different tasks
# depending on the data type (Number, String, List, Object, etc.)

# + with integers -> Addition
print(2 + 2)          # Output: 4

# + with strings -> Concatenation (Joining)
print("2" + "2")      # Output: 22

# + with lists -> Merge two lists
print([1,2,3] + [5,6,7,8])   # Output: [1,2,3,5,6,7,8]


# --------------------------------
# Creating our own class
# --------------------------------

class A():

    # Constructor
    # Stores the value passed while creating the object
    def __init__(self, x):
        self.x = x

    # This method is automatically called when we use +
    # Example:
    # a + b
    # Python internally converts it to:
    # a.__add__(b)
    def __add__(self, other):
        return self.x + other.y

    # This method is automatically called when we use -
    # Example:
    # a - b
    # Python internally converts it to:
    # a.__sub__(b)
    def __sub__(self, other):
        return self.x - other.y


class B():

    # Constructor
    def __init__(self, y):
        self.y = y


# Creating objects
a = A(8)      # self.x = 8
b = B(9)      # self.y = 9


# --------------------------------
# List Example
# --------------------------------

l1 = [1,2,3,4,5,6,6]
l2 = [1,2,3,4,5,6,6]

# List + List = Merge both lists
print(l1 + l2)

# Python internally does:
# l1.__add__(l2)


# --------------------------------
# Object Example
# --------------------------------

# Uncomment the line below to test addition
# Python internally calls:
# a.__add__(b)

# self = a
# other = b
# self.x = 8
# other.y = 9
# 8 + 9 = 17

# print(a + b)


# Uncomment the line below to test subtraction
# Python internally calls:
# a.__sub__(b)

# self = a
# other = b
# self.x = 8
# other.y = 9
# 8 - 9 = -1

# print(a - b)

# +  -> __add__()
# -  -> __sub__()
# *  -> __mul__()
# == -> __eq__()
# /  -> __truediv__()

# Whenever we use an operator with objects,
# Python automatically calls the corresponding special (dunder) method
# # dunder function

# =====================================
# Dunder (Magic / Special) Functions
# =====================================

# Dunder means "Double UnderScore"
# These are special methods in Python.
# They start and end with double underscores (__).
#
# Examples:
# __init__
# __str__
# __add__
# __sub__
# __len__
#
# Python automatically calls these methods when needed.

# -------------------------------------
# Example 1: __init__()
# -------------------------------------

class Student:

    # __init__() is called automatically when an object is created.
    # It is used to initialize (assign) object attributes.

    def __init__(self, name, age):
        self.name = name
        self.age = age

s1 = Student("Ram", 20)

print(s1.name)      # Ram
print(s1.age)       # 20


# -------------------------------------
# Example 2: __str__()
# -------------------------------------

class Student:

    def __init__(self, name):
        self.name = name

    # __str__() is automatically called when we print an object.
    # It returns a readable string representation of the object.

    def __str__(self):
        return f"Student Name : {self.name}"

s1 = Student("Hari")

print(s1)
# Python internally does:
# print(s1.__str__())


# -------------------------------------
# Example 3: __len__()
# -------------------------------------

class Student:

    def __init__(self, subjects):
        self.subjects = subjects

    # __len__() is automatically called when len() is used.

    def __len__(self):
        return len(self.subjects)

s1 = Student(["Python", "Java", "C++"])

print(len(s1))
# Python internally does:
# s1.__len__()


# -------------------------------------
# Example 4: __add__()
# -------------------------------------

class Number:

    def __init__(self, value):
        self.value = value

    # __add__() is automatically called when + operator is used.

    def __add__(self, other):
        return self.value + other.value

n1 = Number(10)
n2 = Number(20)

print(n1 + n2)
# Python internally does:
# n1.__add__(n2)


# -------------------------------------
# Example 5: __sub__()
# -------------------------------------

class Number:

    def __init__(self, value):
        self.value = value

    # __sub__() is automatically called when - operator is used.

    def __sub__(self, other):
        return self.value - other.value

n1 = Number(30)
n2 = Number(10)

print(n1 - n2)
# Python internally does:
# n1.__sub__(n2)


# -------------------------------------
# Example 6: __eq__()
# -------------------------------------

class Student:

    def __init__(self, marks):
        self.marks = marks

    # __eq__() is automatically called when == operator is used.

    def __eq__(self, other):
        return self.marks == other.marks

s1 = Student(80)
s2 = Student(80)

print(s1 == s2)
# Python internally does:
# s1.__eq__(s2)


# =====================================
# Common Dunder Functions
# =====================================

# __init__()      -> Object creation
# __str__()       -> print(object)
# __len__()       -> len(object)
# __add__()       -> +
# __sub__()       -> -
# __mul__()       -> *
# __truediv__()   -> /
# __eq__()        -> ==
# __lt__()        -> <
# __gt__()        -> >
# __getitem__()   -> object[index]
# __call__()      -> object()

# =====================================
# Easy Trick for Students
# =====================================

# Whenever you use...

# obj1 + obj2
# Python calls:
# obj1.__add__(obj2)

# obj1 - obj2
# Python calls:
# obj1.__sub__(obj2)

# print(obj)
# Python calls:
# obj.__str__()

# len(obj)
# Python calls:
# obj.__len__()

# obj1 == obj2
# Python calls:
# obj1.__eq__(obj2)

# -------------------------------------
# Remember:
# Dunder functions are called automatically by Python.
# We usually don't call them directly.
# They help us customize the behavior of our objects.
# -------------------------------------