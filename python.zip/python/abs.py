#  Abstraction means hiding unnecessary implementation details and showing only the 
# essential features to the user or services.
# the proccess of handling complexity

# kkatii kura kun code kasari kam garnu parxa vanni kura jannu abashek xaina 
from mul import multiply
print(multiply(2,2,4,6))

print(len([2,2,4,6]))

# len

# to achive abastraction we use abstract class
# and abstrac method

# abstract class : it is blueprint of other class

# abstract class: a class contain more than of obstract method

# abstract method: a method that has declaration but doesnot implementation

from abc import abstractmethod, ABC

class A(ABC):
# 
#atleat aauta cass xa vane 
    @abstractmethod
    def show(self):
        pass

    @abstractmethod
    def home(self):
        pass

#  method that has declaration but doesnot implementation

# class B(A):
#     def display(self):
#         print("hello")

#     def show(self):
#         print("hello okey")
# ob = B()
# ob.display() # output Hello aaunu parni tara kyai aaudaina
# ans aaunako tyo method nai call hunuparxa


class D(A):
    def hello(self):
        print("hello pramila")

    def show(self):
        print("asdf")

    def home(self):
        print("asdf")
ob = D()
ob.hello()



# yadi yo abstract vayana vani tyo function chai
# chanu vayan avanera banako ho 


# for example ragister nagari check out garna paunu vayaba


# kunai saman order garnu xa vani register chai hunu paryo


