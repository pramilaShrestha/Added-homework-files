# for i in range(3):
#     print("Hello")


# for i in range(1,10):
#     if i %2 == 0:
#         print(i)

# Number Ko Square Print Garne
for i in range(1, 6):
    print(i * i)
  

# Multiplication Table of 5
num = 5

for i in range(1, 11):
    print(num, "x", i, "=", num * i)




# Sum of Numbers 1 to 5
total = 0 
for i in range (1, 10):
    total = total + i

print("Sum: ", total)



# List Ko Elements Print Garne
fruits = ["Apple", "Mango", "Banana"]

for fruit in fruits:
    print(fruit)


# Reverse Counting
for i in range(10, 0, -1):
    print(i)


# Q1 Print "Python" 10 times.

# Q2 Print numbers from 1 to 20.

# Q3 Print even numbers from 2 to 20.

# Q4 Print odd numbers from 1 to 19.

# Q5 Print multiplication table of 7.

# Q6 Find the sum of numbers from 1 to 100.


# Sum of Even Numbers (1–100)

total = 0
for i in range (1 , 100):
    if i % 2 == 0 :
        total = total + i 

print(total)


# Factorial of a Number
n = 5
fact = 1

for i in range(1, n+1):
    fact = fact * i

print("Factorial =", fact)



#Largest Number in List
nums = [12, 45, 8, 99, 32]
largest = nums[0]

for i in nums:
    if i > largest:
        largest = i

print("Largest = ", largest)


# Fibonacci (User Input)
n = int(input("Enter number of terms: "))

a = 0
b = 1

for i in range(n):
    print(a, end=" ")
    c = a + b
    a = b
    b = c