"""
HANDICRAFT BILLING SYSTEM
=========================
A console-based billing system for a local handicraft store in Patan,
built using Object-Oriented Programming (OOP) in Python.

Concepts demonstrated:
- Classes, Objects, Constructors (__init__), Methods, Encapsulation
- Variables, Data Types, Operators
- Conditional Statements, Loops
- Functions, Modules (import)
- Exception Handling (try/except)
"""


# =========================================================
#  PRODUCT CLASS
# =========================================================
class Product:
    """Represents a single handicraft product sold in the store."""

    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def __str__(self):
        return f"{self.product_id:<4}{self.name:<20}Rs.{self.price:.2f}"


# =========================================================
#  STORE CLASS
# =========================================================
class Store:
    """
    Represents the handicraft store itself.
    Holds the fixed (hard-coded) catalogue of 10 products and
    provides lookup / display behaviour for the product menu.
    """

    def __init__(self):
        # Product catalogue stored as a dictionary: {product_id: Product}
        self._products = {
            1: Product(1, "Dhaka Topi", 800),
            2: Product(2, "Lokta Notebook", 350),
            3: Product(3, "Wooden Mask", 1200),
            4: Product(4, "Mithila Painting", 2500),
            5: Product(5, "Singing Bowl", 1800),
            6: Product(6, "Pashmina Shawl", 3000),
            7: Product(7, "Handmade Bracelet", 250),
            8: Product(8, "Ceramic Vase", 900),
            9: Product(9, "Khukuri Keychain", 400),
            10: Product(10, "Bamboo Basket", 700),
        }

    def get_product(self, product_id):
        """Returns the Product for a given ID, or None if it doesn't exist."""
        return self._products.get(product_id)

    def display_products(self):
        """Prints the full list of products with their prices."""
        print("\n====================================")
        print("           PRODUCT LIST")
        print("====================================")
        print(f"{'ID':<4}{'Product Name':<20}{'Price'}")
        print("------------------------------------")
        for product in self._products.values():
            print(product)
        print("====================================")


# =========================================================
#  BILL ITEM CLASS
# =========================================================
class BillItem:
    """Represents a single line item within a bill (one product + quantity)."""

    def __init__(self, product, quantity):
        self.product = product
        self.quantity = quantity

    def get_subtotal(self):
        return self.product.price * self.quantity


# =========================================================
#  BILL CLASS
# =========================================================
class Bill:
    """
    Represents one customer's confirmed bill.
    Calculates the total, the 12% charity donation, the 88% store
    income, and prints a formatted receipt.
    """

    CHARITY_RATE = 0.12

    _bill_counter = 0  # class-level counter so every bill gets a unique number

    def __init__(self, customer_name):
        Bill._bill_counter += 1
        self.bill_number = Bill._bill_counter
        self.customer_name = customer_name
        self.items = []  # list of BillItem objects

    def add_item(self, product, quantity):
        self.items.append(BillItem(product, quantity))

    def is_empty(self):
        return len(self.items) == 0

    def get_total(self):
        return sum(item.get_subtotal() for item in self.items)

    def get_charity_amount(self):
        return self.get_total() * self.CHARITY_RATE

    def get_store_income(self):
        return self.get_total() - self.get_charity_amount()

    def print_bill(self):
        """Prints the itemised bill in the required format."""
        total = self.get_total()
        charity = self.get_charity_amount()
        store_income = self.get_store_income()

        print("\n======================================")
        print("          CUSTOMER BILL")
        print(f"          Bill No: {self.bill_number}")
        print(f"          Customer: {self.customer_name}")
        print("======================================")
        print(f"{'Product':<20}{'Qty':<9}{'Price'}")
        print("--------------------------------------")
        for item in self.items:
            print(f"{item.product.name:<20}{item.quantity:<9}Rs.{item.get_subtotal():.0f}")
        print("--------------------------------------")
        print(f"{'Total Bill':<22}: Rs.{total:.0f}")
        print(f"{'Charity (12%)':<22}: Rs.{charity:.0f}")
        print(f"{'Store Income (88%)':<22}: Rs.{store_income:.0f}")
        print(f"{'Amount to Pay':<22}: Rs.{total:.0f}")
        print("======================================")


# =========================================================
#  BILLING SYSTEM CLASS (coordinates Store + Bill creation)
# =========================================================
class BillingSystem:
    """
    Top-level controller class that ties the Store and Bill classes
    together and manages the customer-serving workflow (up to 5
    customers per program run).
    """

    MAX_CUSTOMERS = 5

    def __init__(self):
        self.store = Store()
        self.customers_served = 0

    # ---------------------------------------------------
    # Helper: safely read a positive integer from the user
    # ---------------------------------------------------
    @staticmethod
    def _read_int(prompt):
        while True:
            try:
                value = int(input(prompt).strip())
                return value
            except ValueError:
                print("Invalid input. Please enter a whole number.")

    # ---------------------------------------------------
    # Create a new bill for one customer
    # ---------------------------------------------------
    def create_new_bill(self):
        if self.customers_served >= self.MAX_CUSTOMERS:
            print(f"\nMaximum of {self.MAX_CUSTOMERS} customers already served in this session.")
            return

        print(f"\n--- New Bill (Customer {self.customers_served + 1} of {self.MAX_CUSTOMERS}) ---")
        customer_name = input("Enter customer name: ").strip()
        if not customer_name:
            customer_name = "Guest"

        bill = Bill(customer_name)
        self.store.display_products()

        while True:
            product_id = self._read_int("\nEnter Product ID to add (0 to finish order): ")

            if product_id == 0:
                break

            product = self.store.get_product(product_id)
            if product is None:
                print("Invalid Product ID. Please choose a valid ID from the list.")
                continue

            quantity = self._read_int(f"Enter quantity for '{product.name}': ")
            if quantity <= 0:
                print("Quantity must be at least 1. Item not added.")
                continue

            bill.add_item(product, quantity)
            print(f"Added: {quantity} x {product.name}")

        if bill.is_empty():
            print("\nNo items were added. Bill cancelled.")
            return

        bill.print_bill()
        self.customers_served += 1

    # ---------------------------------------------------
    # Main menu loop
    # ---------------------------------------------------
    def run(self):
        print("Welcome to the Patan Handicraft Store Billing System!")

        while True:
            print("\n====================================")
            print("      HANDICRAFT BILLING SYSTEM")
            print("====================================")
            print("1. View Products")
            print("2. Create New Bill")
            print("3. Exit")

            choice = input("Enter your choice: ").strip()

            if choice == "1":
                self.store.display_products()

            elif choice == "2":
                if self.customers_served >= self.MAX_CUSTOMERS:
                    print(f"\nMaximum of {self.MAX_CUSTOMERS} customers reached. "
                          f"Please restart the program to serve more customers.")
                else:
                    self.create_new_bill()

                    if self.customers_served < self.MAX_CUSTOMERS:
                        cont = input("\nDo you want to continue with the next customer? (y/n): ").strip().lower()
                        if cont not in ("y", "yes"):
                            print("\nEnding session at the shopkeeper's request.")
                            break
                    else:
                        print(f"\nMaximum of {self.MAX_CUSTOMERS} customers served for this session.")

            elif choice == "3":
                print("\nExiting the Handicraft Billing System. Goodbye!")
                break

            else:
                print("\nInvalid choice. Please enter 1, 2, or 3.")


# =========================================================
#  PROGRAM ENTRY POINT
# =========================================================
def main():
    system = BillingSystem()
    try:
        system.run()
    except KeyboardInterrupt:
        print("\n\nProgram interrupted by user. Exiting safely.")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")


if __name__ == "__main__":
    main()