# num = int(input("Enter a Number: "))

# # if num > 0:
# #     print("positive number")

# # elif num < 0 :
# #     print("Nagative Number")
# # else :
# #     print("Number is zero")

# # if num > 0:
# #     if num%2 == 0 :
# #         print ("Positive  even number ")
# #     else: 
# #         print("Positive odd number")

# # else: 
# #     print("number is zero")

# if num >= 18 and num <= 105:
#     if num >= 60:
#         print ("Senior Voter")
#     else: 
#         print("adult Voter")
    
# elif num >= 105:
#     print("invalide Age")

# else:
#     print("Not Eligible for vote ")



# from unicodedata import name


# def greet():
#     name = "Ram"      # Local Variable
#     print(name)

# greet()

# print(name)   # NameError: name 'name' is not defined



# name = "ram"
# def display():
#     age = 20 
#     name = "Sita"

#     print(name)
#     print(age)

# display()





# def show(a):          # show() naam ko function banayo
#     return a + 2      # a ma 2 add garera return garcha

# v = [1, 2, 3, 4, 5]   # euta list banayo

# result = map(show, v) # map() le v ko harek element lai show() ma pathaucha
#                        # show(1), show(2), show(3), show(4), show(5)

# print(list(result))   # map object lai list ma convert garera print garcha



# def show(a):
#     return a + 2 

# v = [1,2,3,4,5]

# print(show(v))

# v = [1,2,3,4,5]
# # using lamda
# abc = lambda a: a**2
# var = map(abc, v)
# print(list(var))


# o = [1,2,3,4,5,6,7,8]

# def show(c):
#     return c % 2 == 0 

# var = filter(show, o)

# print(list(var))



# numbers = [1, 2, 3, 4, 5, 6]

# result = filter(lambda x: x % 2 == 0, numbers)

# print(list(result))


# o = [1,3,4,5,6]
# def show(c):
#     return c %2 == 0

# var = filter(show, o)

# print(list(var))




# from functools import reduce
# numbers = (1, 2, 3, 4, 5)  

# # def add(x,y):
# #     return x + y

# # result = reduce(reduce(add, numbers))


# result = reduce(lambda x, y: x + y, numbers)

# print(result)


# marks = [35, 78, 45, 90, 23, 67]

# result = list(filter(lambda x: x > 50, marks))
# print(result)

# words = ["apple", "cat", "banana", "dog", "orange"]

# result = list(filter(lambda x: len(x) > 5, words))
# print(result)


# numbers = [1,2,3,4,5,6]

# result = ["even" if x % 2 == 0 else "odd" for x in numbers]

# print (result)


# result = [x for x in numbers if x%2 == 0]
# print(result)




# Example 4: Uppercase / Lowercase

# words = ["apple", "banANA", "mango", "ORANGE"]

# result = [word.lower() if word.isupper() else word.upper()
#           for word in words]

# print(result)


# ['APPLE', 'banana', 'MANGO', 'orange']

# inheritance 

# class Animal:
#     def eat (self):
#         print("animal is eating")

# class Dog(Animal):
#     def bark(self):
#         print ("dog is barking")


# d = Dog()
# d.bark()
# d.eat()


# class Father:
#     def skills1(self):
#         print("Driving")

# class Mother:
#     def skills2(self):
#         print("cooking")

# class child(Father, Mother):
#     def skills3(self):
#         print("Reading")


# b1 = child()
# b1.skills1()
# b1.skills2()
# b1.skills3()




# # multilevel Inheritance 

# class Grandparent:
#     def show1(self):
#         print("GrandParent class")

# class Parent(Grandparent):
#     def show2(self):
#         print("parent class")

# class Child(Parent):
#     def show3(self):
#         print("Child class")

# # c1 = Child()
# # c1.show1()
# # c1.show2()
# # c1.show3()

# c1 = Parent()

# c1.show1()
# c1.show2()


#  Hierarchical Inheritance

# 1 parent - multiple child

# class Vehicle:
#     def info(self):
#         print("this is vehicle")

# class Car(Vehicle):
#     def car_info(self):
#         print("This is a car")

# class Bike(Vehicle):
#     def bike_info(self):
#         print("this is bike")


# c1 = Car()
# b1 = Bike()
# c1.info()
# c1.car_info()

# b1.info()
# b1.bike_info()



"""Question

Create a Python program using Single Inheritance to manage a student's academic record.

Requirements
Create a parent class named Person.
Data members:
name
age
Create a constructor to initialize these values.
Create a method display_person() to display the person's details.
Create a child class named Student that inherits from Person.
Additional data members:
roll_no
faculty
Marks in:
Python
Java
DBMS
Networking
AI
Initialize all required data members.
Create the following methods:
calculate_total()
calculate_percentage()
calculate_grade()
Display:
Student Name
Age
Roll Number
Faculty
Marks of all subjects
Total Marks
Percentage
Grade
Create one object of the Student class and display the complete result.
"""



# class Person:
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age

#     def display_person(self):
#         print("Name       :", self.name)
#         print("Age        :", self.age)


# # Child Class
# class Student(Person):
#     def __init__(self, name, age, roll_no, faculty, python, java, dbms, networking, ai):
#         Person.__init__(self, name, age)

#         self.roll_no = roll_no
#         self.faculty = faculty
#         self.python = python
#         self.java = java
#         self.dbms = dbms
#         self.networking = networking
#         self.ai = ai

#     def calculate_total(self):
#         return self.python + self.java + self.dbms + self.networking + self.ai

#     def calculate_percentage(self):
#         return self.calculate_total() / 5

#     def calculate_grade(self):
#         percentage = self.calculate_percentage()

#         if percentage >= 90:
#             return "A+"
#         elif percentage >= 80:
#             return "A"
#         elif percentage >= 70:
#             return "B+"
#         elif percentage >= 60:
#             return "B"
#         elif percentage >= 50:
#             return "C"
#         else:
#             return "Fail"

#     def display(self):
#         print("========== STUDENT DETAILS ==========")
#         self.display_person()

#         print("Roll No    :", self.roll_no)
#         print("Faculty    :", self.faculty)

#         print("\nMarks")
#         print("Python     :", self.python)
#         print("Java       :", self.java)
#         print("DBMS       :", self.dbms)
#         print("Networking :", self.networking)
#         print("AI         :", self.ai)

#         print("\nTotal      :", self.calculate_total())
#         print("Percentage :", self.calculate_percentage())
#         print("Grade      :", self.calculate_grade())


# # Create Object
# s1 = Student(
#     "Ram Sharma",
#     20,
#     15,
#     "BIT",
#     85,
#     80,
#     78,
#     88,
#     90
# )

# # Display Result
# s1.display()



# class Student:
#     def __init__(self):
#         self.__name = "Pramila"

#     def __show(self):
#         print(f"hello is {self.__name}")

# ob = Student()
# # print(ob.__name)  #variable lai class bahira bata access garna milxa
# ob.show()


# # class B():
# #     def display(self):
# #         print("this display features", ob.name)  # mathiko variable lai ni access garna milyo

# # v = B()
# # v.display()

# def check(num):
#     if num > 0:
#         print("Positive")
#     else:
#         print("Negative")
# print(check(5))


# class Student:
#     def __init__(self):
#         self._name="Pramila"

#     def __show(self):
#         print(f"This is {self._name}") 

#     def dis(self):
#         self.__show()

# ob = Student()
# ob.dis() 
# print(ob.name)     

# class B(Student):
#     def display(self):
#         print(f"this is display funtion{self._name}")


# v = B()
# v.display()




"""Question

Create a class named Electricity.

Create a method named bill() using default arguments (None) that performs 
the following tasks:

If no arguments are provided, print "No Data Found".
If only Units are provided, calculate the bill at Rs. 12 per unit.

If Units and Rate are provided, calculate the bill using the formula:
Bill = Units × Rate

If Units, Rate, and Tax (%) are provided, calculate the Final Bill by adding the tax 
to the total bill."""






class Electricity:
    def bill(self, units=None, rate=None, tax=None):

        if units == None and rate == None and tax == None:
            print("No Data Found")

        elif units != None and rate == None and tax == None:
            total = units * 12
            print("Units =", units)
            print("Bill = Rs.", total)

        elif units != None and rate != None and tax == None:
            total = units * rate
            print("Units =", units)
            print("Rate = Rs.", rate)
            print("Bill = Rs.", total)

        elif units != None and rate != None and tax != None:
            total = units * rate
            final_bill = total + (total * tax / 100)
            print("Units =", units)
            print("Rate = Rs.", rate)
            print("Tax =", tax, "%")
            print("Final Bill = Rs.", final_bill)

        else:
            print("Invalid Input")


obj = Electricity()

obj.bill()
print()

obj.bill(100)
print()

obj.bill(100, 15)
print()

obj.bill(100, 15, 13)


