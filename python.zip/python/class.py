# Encpatulation : the rapping the data and method with single unit
# hiding internal state object and restrict direct access from outside

# why
# data secure
# data hiding
# contorl access to the data

# encaptulatio is achived by using access modifier
# private, protected, public  : access modifier 
    # private: attribute and method are accessible only in that class
    # protected : attribute and method are accessible only in that class and subclass
    # public: attribute and method are accessible from outside class





# public: 

# class Student: 
#     def __init__(self,name):
#         self.name = name

#     def show(self):
#         print(f"This is {self.name}"

# class B(Student):
#     def display(self):
#         print(f"this is display{self.name}")

# ob = B("Pramila")
# ob.display()

# with private accessfier : __variable_name 
# class Student: 
#     def __init__(self,name):
#         self._name = name

#     def __show(self):
#         print(f"This is {self._name}")

#     def display(self):
#         self.__show()

    

# ob1 = Student("Pramila")
# ob1.display()
# # print(ob1.__name)






# class B(Student):
#     def display(self):
#         print(f"this is display{self.__name}")

# ob = B("Pramila")
# ob.display()

"""Create a Python class named ATM to manage a bank account using the Private Access Modifier.

Requirements:
Create a private attribute named __balance and initialize it using the constructor (__init__).
Create a method named deposit(amount) that:
Adds the given amount to the account balance.
Displays the message "Deposit Successful".
Create a method named withdraw(amount) that:
Deducts the given amount if there is sufficient balance.
Displays "Withdrawal Successful" if the transaction is successful.
Otherwise, displays "Insufficient Balance".
Create a method named show_balance() that displays the current account balance.
Create an object with an initial balance of 10000 and perform the following operations:
Display the current balance.
Deposit 5000.
Display the updated balance.
Withdraw 3000.
Display the final balance.
Finally, try to access the private attribute directly using atm.__balance and observe the result"""

# class ATM:
#     def __init__(self, balance):
#         self.__balance = balance

#     def deposit(self, amount):
#         self.__balance += amount
#         print("Deposit Successful")

#     def withdraw(self, amount):
#         if amount <= self.__balance:
#             self.__balance -= amount
#             print("Withdrawal Successful")
#         else:
#             print("Insufficient Balance")

#     def show_balance(self):
#         print("Current Balance:", self.__balance)


# atm = ATM(10000)

# atm.show_balance()

# atm.deposit(5000)

# atm.show_balance()

# atm.withdraw(3000)

# atm.show_balance()

# class Student: 
#     def __init__(self,name):
#         self.__name = name

#     def show(self):
#         print(f"This is {self.__name}")

# class B(Student):
#     def display(self):
#         print(f"this is display{self.__name}")

# ob = Student("Pramila")
# print(ob.__dict__)
# print(ob._Student__name) 







