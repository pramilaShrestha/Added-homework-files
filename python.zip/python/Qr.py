import qrcode
# pip install pillow
# pip install Qrcode

print("QR Code Generated")
qr = qrcode.QRCode(
    version=1, box_size=40, border=4 )
qr.add_data("hi this is me")
qr.make(fit=True)
qr.make_image(fill_color="black", back_color="white").save("qr.png")






# import qrcode

# # User bata data line
# data = input("Enter text or URL for QR Code: ")

# # QR Code object create garne
# qr = qrcode.QRCode(
#     version=1,
#     box_size=40,
#     border=4
# )

# # User ko data add garne
# qr.add_data(data)
# qr.make(fit=True)

# # Image create ra save garne
# img = qr.make_image(fill_color="black", back_color="white")

# filename = input("Enter file name (without extension): ")
# img.save(filename + ".png")

# print(f"QR Code saved as {filename}.png")



