# oop 
# Programming Paradigms
# 1. Porcedural programming language
# 2 . OOP

# OOP : Organized , easy to maintain, reusablity

# Class : blue print of object , it can define behaviour and attributes of object.  

# object : Multiple objects can be created from the same class.

# constructor : It is automatically called whenever an object is created.
## Purpose
    # Initialize object attributes
    # Assign initial values to an object


# The `self` Keyword
    # `self` refers to the current object.
    # It is used to access the attributes and methods of that object.


# class Student:
#     def __init__(self, name, age):
#         self.name = name  # attributes 
#         self.age = age


#     def show(self): # methods
#         print(f"This is {self.name} and {self.age}")


# ob = Student("Ram", 45)
# ob.show()

# ob1 = Student("Ram1", 45)
# ob1.show()



# shop

class Shop:
    def __init__(self, P_name, price, qty):
        self.P_name = P_name
        self.price = price
        self.qty = qty

    def show(self):
        print(f'Total Price of {self.P_name} is {self.price * self.qty}')


P_name = input("Enter an item: ")
price = int(input("Enter a price: "))
qty = int(input("Enter a quantity: "))

ob = Shop(P_name, price, qty)
ob.show()




"""Task 

Question: Student Grade System (OOP)

Create a class named Student with the following attributes:

name
marks

Create a method named grade() that displays the student's grade based on the following criteria:

Marks	Grade
90 and above	A
80 – 89	B
70 – 79	C
60 – 69	D
Below 60	Fail

Instructions:

Create a constructor (__init__()) to initialize the student's name and marks.
Take the student's name and marks as input from the user.
Create a Student object.
Call the grade() method to display the student's grade."""








